% Especifica la ubicación del directorio que contiene las imágenes
directorio = 'D:\DOCTORADO EN TECNOLOGIA\ESTANCIAS EA 2023\Mediciones Piezas\Mediciones Meraz\Signature 1\Aluminio\resultados contorno';

% Obtiene una lista de archivos en el directorio
archivos = dir(fullfile(directorio, '*.jpg')); % Puedes cambiar la extensión según el tipo de archivo

% Verifica si hay al menos 45 imágenes en el directorio
if length(archivos) < 45
    error('No hay suficientes imágenes en el directorio.');
end

% Crea una figura para mostrar las imágenes
figure;

% Loop para mostrar las primeras 45 imágenes
for i = 1:45
    % Lee la imagen
    imagen = imread(fullfile(directorio, archivos(i).name));
    
    % Subtrama 5x9 para mostrar 45 imágenes
    subplot(5, 9, i);
    
    % Muestra la imagen
    imshow(imagen);
    
    % Título con el nombre del archivo
    title(archivos(i).name, 'Interpreter', 'none');
end

% Ajusta el espacio entre las imágenes
set(gcf, 'Position', get(0, 'Screensize')); % Maximiza la ventana de la figura

% Opcional: puedes ajustar el tamaño de la imagen en la ventana de la figura
% Para ello, puedes usar la función "imresize".

% Ejemplo de redimensionar las imágenes a un tamaño específico
% for i = 1:45
%     imagen = imread(fullfile(directorio, archivos(i).name));
%     imagen = imresize(imagen, [100, 100]); % Cambia el tamaño a 100x100 píxeles
%     subplot(5, 9, i);
%     imshow(imagen);
%     title(archivos(i).name, 'Interpreter', 'none');
% end
